# Claude Code Setup Kit

Drop-in configuration for Claude Code that provides:
- A global playbook (CLAUDE.md) with task management, verification, and agent fleet patterns
- 4 specialist agents: architect, pr-reviewer, triage-agent, feature-coordinator
- Self-improvement loop via KNOWLEDGE.md (append-only knowledge base)
- Lessons log for capturing corrections and mistakes
- PR quality gate hook (runs lint, typecheck, tests on PR creation)

## Installation

1. Unzip into your project root
2. Customise `CLAUDE.md`:
   - Update the "Architecture Rules" section with your project-specific rules
   - Update the "Verification Commands" table with your project's lint/test/build commands
   - Update "User Preferences" to match your workflow
3. Optionally customise `.claude/settings.json` hook commands for your stack
4. Commit all files to your repo

## File Structure

```
CLAUDE.md                           — Global playbook (project conventions, agent fleet, task workflow)
KNOWLEDGE.md                        — Append-only knowledge base (patterns, decisions, gotchas)
tasks/lessons.md                    — Correction log (mistakes → rules)
.claude/settings.json               — Hooks (PR quality gate)
.claude/agents/architect.md         — Architecture planning agent
.claude/agents/pr-reviewer.md       — Independent code review agent
.claude/agents/triage-agent.md      — Idea/bug intake agent
.claude/agents/feature-coordinator.md — Multi-chunk feature orchestration agent
```

## What to Customise

| File | What to change |
|------|---------------|
| `CLAUDE.md` | Architecture Rules section, Verification Commands table, User Preferences |
| `.claude/settings.json` | Hook commands (lint, typecheck, test) for your stack |
| `.claude/agents/architect.md` | Add project-specific architecture constraints |
| `.claude/agents/pr-reviewer.md` | Add project-specific review checklists |

## What NOT to Edit

- `KNOWLEDGE.md` entries — append only, never edit or delete
- `tasks/lessons.md` entries — append only
- Agent names in `.claude/agents/` — the CLAUDE.md references them by name
