import { storage } from './dbStorage';

// Role hierarchy definition with inheritance rules
const ROLE_HIERARCHY = {
  'super_admin': {
    level: 100,
    inheritsFrom: [],
    description: 'Full system access with all permissions'
  },
  'admin': {
    level: 80,
    inheritsFrom: ['coach'],
    description: 'Administrative access with user management'
  },
  'coach': {
    level: 60,
    inheritsFrom: ['user'],
    description: 'Coaching access with limited admin features'
  },
  'user': {
    level: 40,
    inheritsFrom: [],
    description: 'Standard user access'
  },
  'guest': {
    level: 20,
    inheritsFrom: [],
    description: 'Limited guest access'
  }
} as const;

export type RoleName = keyof typeof ROLE_HIERARCHY;

export class RoleHierarchyManager {
  
  /**
   * Validates role hierarchy to prevent circular dependencies
   */
  static validateRoleHierarchy(): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    const visited = new Set<string>();
    const recursionStack = new Set<string>();

    const hasCycle = (role: string): boolean => {
      if (recursionStack.has(role)) {
        errors.push(`Circular dependency detected involving role: ${role}`);
        return true;
      }
      
      if (visited.has(role)) {
        return false;
      }

      visited.add(role);
      recursionStack.add(role);

      const roleConfig = ROLE_HIERARCHY[role as RoleName];
      if (roleConfig) {
        for (const inheritedRole of roleConfig.inheritsFrom) {
          if (hasCycle(inheritedRole)) {
            return true;
          }
        }
      }

      recursionStack.delete(role);
      return false;
    };

    // Check each role for cycles
    for (const role of Object.keys(ROLE_HIERARCHY)) {
      if (!visited.has(role)) {
        hasCycle(role);
      }
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Gets all roles that a given role inherits from (recursive)
   */
  static getInheritedRoles(role: string): string[] {
    const inherited = new Set<string>();
    const visited = new Set<string>();

    const collectInherited = (currentRole: string) => {
      if (visited.has(currentRole)) return;
      visited.add(currentRole);

      const roleConfig = ROLE_HIERARCHY[currentRole as RoleName];
      if (roleConfig) {
        for (const inheritedRole of roleConfig.inheritsFrom) {
          inherited.add(inheritedRole);
          collectInherited(inheritedRole);
        }
      }
    };

    collectInherited(role);
    return Array.from(inherited);
  }

  /**
   * Checks if roleA has higher or equal authority than roleB
   */
  static hasAuthorityOver(roleA: string, roleB: string): boolean {
    const levelA = ROLE_HIERARCHY[roleA as RoleName]?.level || 0;
    const levelB = ROLE_HIERARCHY[roleB as RoleName]?.level || 0;
    return levelA >= levelB;
  }

  /**
   * Gets all permissions for a role including inherited permissions
   */
  static async getEffectivePermissions(role: string): Promise<any[]> {
    const allRoles = [role, ...this.getInheritedRoles(role)];
    const allPermissions = new Map();

    for (const currentRole of allRoles) {
      const rolePermissions = await storage.getRolePermissions(currentRole);
      for (const permission of rolePermissions) {
        if (!allPermissions.has(permission.permissionId)) {
          allPermissions.set(permission.permissionId, permission);
        }
      }
    }

    return Array.from(allPermissions.values());
  }

  /**
   * Validates if a user can assign a role to another user
   */
  static canAssignRole(assignerRole: string, targetRole: string): boolean {
    // Super admin can assign any role
    if (assignerRole === 'super_admin') return true;
    
    // Users can only assign roles lower than their own
    return this.hasAuthorityOver(assignerRole, targetRole) && assignerRole !== targetRole;
  }

  /**
   * Gets role hierarchy information
   */
  static getRoleHierarchy() {
    return ROLE_HIERARCHY;
  }

  /**
   * Gets suggested role progression path
   */
  static getRoleProgression(currentRole: string): string[] {
    const currentLevel = ROLE_HIERARCHY[currentRole as RoleName]?.level || 0;
    
    return Object.entries(ROLE_HIERARCHY)
      .filter(([_, config]) => config.level > currentLevel)
      .sort((a, b) => a[1].level - b[1].level)
      .map(([role, _]) => role);
  }

  /**
   * Bulk permission assignment with inheritance validation
   */
  static async assignPermissionsWithInheritance(
    role: string, 
    permissionIds: number[]
  ): Promise<{ success: boolean; conflicts: string[] }> {
    const conflicts: string[] = [];
    
    // Get inherited roles to check for conflicts
    const inheritedRoles = this.getInheritedRoles(role);
    
    // Check if any permissions would conflict with inherited permissions
    for (const inheritedRole of inheritedRoles) {
      const inheritedPermissions = await storage.getRolePermissions(inheritedRole);
      const inheritedPermissionIds = inheritedPermissions.map(p => p.permissionId);
      
      const duplicates = permissionIds.filter(id => inheritedPermissionIds.includes(id));
      if (duplicates.length > 0) {
        conflicts.push(`Role ${role} inherits permissions ${duplicates.join(', ')} from ${inheritedRole}`);
      }
    }

    if (conflicts.length > 0) {
      return { success: false, conflicts };
    }

    // Assign permissions
    for (const permissionId of permissionIds) {
      await storage.createRolePermission({
        role,
        permissionId
      });
    }

    return { success: true, conflicts: [] };
  }
}

// Role templates for common use cases
export const ROLE_TEMPLATES = {
  'financial_advisor': {
    basedOn: 'coach',
    additionalPermissions: [
      'financial_planning_view',
      'financial_planning_edit',
      'user_sessions_view',
      'analytics_view'
    ],
    description: 'Financial planning specialist with coaching abilities'
  },
  'content_manager': {
    basedOn: 'user',
    additionalPermissions: [
      'content_create',
      'content_edit',
      'content_publish',
      'steps_view'
    ],
    description: 'Content creation and management specialist'
  },
  'support_agent': {
    basedOn: 'user',
    additionalPermissions: [
      'user_support_view',
      'user_sessions_view',
      'audit_logs_view'
    ],
    description: 'Customer support representative'
  }
} as const;

export type RoleTemplate = keyof typeof ROLE_TEMPLATES;