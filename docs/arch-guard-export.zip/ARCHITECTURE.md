# Financial Freedom Blueprint - Test Management Platform Architecture

## Project Overview

This is a comprehensive test management platform that provides an interactive solution for system reliability testing with advanced form configuration and execution capabilities. The platform integrates manual test execution, real-time progress tracking, and sophisticated form field rendering within a Financial Freedom Blueprint application.

## Core Architecture Principles

### Single Responsibility Files
Each file should have one clear purpose. Avoid creating multiple files that handle the same functionality.

### No Duplicate Functions
Before creating a new function, always check if similar functionality already exists in the codebase.

### Test-Driven Development
All features must have comprehensive test coverage. The platform maintains 100% test success rate for form field configuration systems.

## File Structure & Responsibilities

### Database Layer
- **`server/dbStorage.ts`** - SINGLE source for ALL database operations
  - Contains `IStorage` interface and `DatabaseStorage` implementation
  - All CRUD operations for users, sessions, steps, messages, test runs, etc.
  - Comprehensive test coverage with 100% success rate for form field operations
  - Never create additional storage files or classes
  - Interface must match implementation exactly

### Test Management System
- **Form Field Configuration**: Advanced form rendering with configurable field widths (full, half, third, quarter)
- **Real-time Progress Tracking**: Accurate file counts and synchronized updates across UI sections
- **Manual Test Execution**: Manual-only test run initiation to preserve processing power
- **Comprehensive Test Coverage**: All form field configuration tests maintain 100% pass rate

### API Layer
- **`server/routes.ts`** - SINGLE file for ALL API endpoints
  - All Express routes consolidated here
  - Authentication, admin, coach, session, step, and test management routes
  - Manual test execution endpoints with processing power optimization
  - Field reordering and configuration management APIs
  - Never create separate route files
  - Use middleware functions from authentication.ts

### Authentication
- **`server/authentication.ts`** - ALL authentication logic
  - Login, logout, middleware functions
  - User role checking (admin, coach, regular user)
  - Session management
  - Never duplicate auth logic elsewhere

### External Integrations

#### OpenAI Integration
- **`server/lib/openai-service.ts`** - ONLY file for OpenAI API calls
  - Streaming chat completion functionality
  - No other files should directly call OpenAI API
  - Never create separate chat service files

#### Document Processing
- **`server/lib/document-fetcher.ts`** - ONLY file for fetching documents
  - Handles all URL types (Google Docs, PDFs, regular URLs)
  - Session-aware caching
  - Never create separate document processing files

#### Google Drive & PDF Handling
- **`server/lib/google-drive-utils.ts`** - Google Drive specific functions
  - URL resolution, file ID extraction, PDF downloads
  - **`resolveRedirects()`** - ONLY function for URL redirection handling
- **`server/lib/pdf-handler.ts`** - PDF processing functions
  - PDF download, text extraction, base64 conversion
  - Uses google-drive-utils for URL resolution (no duplicates)

## Development Rules

### Before Adding New Code

1. **Search First**: Always search existing files for similar functionality
   ```bash
   grep -r "functionName\|similar_keyword" server/ --include="*.ts"
   ```

2. **Check Interface Alignment**: Ensure database interface matches implementation
   ```bash
   grep -n "async.*(" server/dbStorage.ts | grep -v "private"
   ```

3. **Verify No Route Duplicates**: All routes must be in routes.ts
   ```bash
   grep -r "app\." server/ --include="*.ts" | grep -v "routes.ts"
   ```

### When Creating New Features

1. **Database Operations**: Add to existing `dbStorage.ts`, update interface if needed
2. **API Endpoints**: Add to existing `routes.ts`
3. **Authentication**: Use existing middleware from `authentication.ts`
4. **Document Processing**: Extend `document-fetcher.ts`
5. **OpenAI Calls**: Use `openai-service.ts`

### Prohibited Actions

- ❌ Creating new storage classes or interfaces
- ❌ Creating separate route files
- ❌ Duplicating authentication logic
- ❌ Creating additional OpenAI service files
- ❌ Creating duplicate document processing functions
- ❌ Creating duplicate URL resolution functions

## Code Quality Checks

### Regular Verification Commands

```bash
# Check for duplicate functions
find server/ -name "*.ts" | xargs grep -h "export.*function" | sort | uniq -c | awk '$1 > 1'

# Check for unauthorized route files
grep -r "app\." server/ --include="*.ts" | grep -v "routes.ts" | grep -E "(get|post|put|delete)\("

# Check for duplicate storage implementations
grep -r "class.*Storage\|interface.*Storage" server/ --include="*.ts" | grep -v "dbStorage.ts"

# Verify database interface alignment
grep -c "async.*function" server/dbStorage.ts
```

### Pre-Feature Development Checklist

- [ ] Searched for existing similar functionality
- [ ] Confirmed no duplicate routes will be created
- [ ] Verified database interface/implementation alignment
- [ ] Identified correct single file for new code
- [ ] Checked for existing utility functions to reuse

## File Dependencies

```
routes.ts
├── authentication.ts (auth middleware)
├── dbStorage.ts (data operations)
├── openai-service.ts (AI responses)
└── lib/
    ├── document-fetcher.ts (document processing)
    ├── google-drive-utils.ts (Google Drive operations)
    ├── pdf-handler.ts (PDF processing)
    └── assistant-name-service.ts (name extraction)
```

## Emergency Duplicate Detection

If duplicates are suspected, run comprehensive scan:
```bash
# Function duplicates
find server/ -name "*.ts" -exec grep -l "export.*function" {} \; | xargs grep -h "export.*function" | sort | uniq -c | sort -nr

# Route duplicates  
find server/ -name "*.ts" -exec grep -l "app\." {} \; | grep -v routes.ts

# Storage duplicates
find server/ -name "*.ts" -exec grep -l "Storage" {} \; | grep -v dbStorage.ts
```

## Success Metrics

- Zero duplicate functions across files
- Single source of truth for each responsibility
- Clean dependency graph
- Fast development due to predictable architecture
- Easy maintenance and debugging

---

**Remember**: When in doubt, consolidate rather than create new files. This architecture has been battle-tested and eliminates over 1,400 lines of duplicate code.