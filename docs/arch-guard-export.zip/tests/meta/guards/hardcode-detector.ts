import { readFile } from 'fs/promises';

export interface HardcodeDetectionResult {
  file: string;
  violations: Array<{
    line: number;
    content: string;
    suspiciousValue: string;
    severity: 'error' | 'warning';
  }>;
}

export class HardcodeDetector {
  private readonly criticalFiles = [
    'server/test-counting.ts',
    'server/authentic-test-runner.ts',
    'server/routes-testing.ts',
    'client/src/components/admin/TestStatusTab.tsx'
  ];

  private readonly suspiciousNumbers = [
    '1399', '1159', '240', // Current test counts
    '2369', '172',         // Previous test counts
    '2541', '2295',        // Historical test counts
    '1224', '1249'         // Other hardcoded counts
  ];

  /**
   * Scan critical test infrastructure files for hardcoded values
   */
  async detectHardcodedValues(): Promise<HardcodeDetectionResult[]> {
    const results: HardcodeDetectionResult[] = [];

    for (const filePath of this.criticalFiles) {
      try {
        const violations = await this.scanFileForHardcodes(filePath);
        if (violations.length > 0) {
          results.push({
            file: filePath,
            violations
          });
        }
      } catch (error) {
        console.warn(`Could not scan ${filePath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    return results;
  }

  /**
   * Scan a single file for hardcoded values
   */
  private async scanFileForHardcodes(filePath: string): Promise<Array<{
    line: number;
    content: string;
    suspiciousValue: string;
    severity: 'error' | 'warning';
  }>> {
    const content = await readFile(filePath, 'utf-8');
    const lines = content.split('\n');
    const violations: Array<{
      line: number;
      content: string;
      suspiciousValue: string;
      severity: 'error' | 'warning';
    }> = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lineNumber = i + 1;

      // Skip comments and console logs
      if (this.shouldSkipLine(line)) {
        continue;
      }

      // Check for suspicious numbers
      for (const number of this.suspiciousNumbers) {
        if (line.includes(number)) {
          const severity = this.determineSeverity(line, number);
          violations.push({
            line: lineNumber,
            content: line.trim(),
            suspiciousValue: number,
            severity
          });
        }
      }
    }

    return violations;
  }

  /**
   * Determine if a line should be skipped during scanning
   */
  private shouldSkipLine(line: string): boolean {
    const trimmed = line.trim();
    
    return (
      trimmed.startsWith('//') ||           // Single-line comments
      trimmed.startsWith('*') ||            // Multi-line comment content
      trimmed.startsWith('/*') ||           // Multi-line comment start
      trimmed.includes('console.log') ||    // Console logs
      trimmed.includes('console.error') ||  // Console errors
      trimmed.includes('console.warn') ||   // Console warnings
      trimmed.includes('console.debug') ||  // Console debug
      trimmed.includes('// META-TEST:') ||  // Meta-test documentation
      trimmed.includes('📊 META-TEST:')     // Meta-test logs
    );
  }

  /**
   * Determine severity based on context
   */
  private determineSeverity(line: string, number: string): 'error' | 'warning' {
    const lowerLine = line.toLowerCase();

    // High severity contexts (likely hardcoded logic)
    if (
      lowerLine.includes('totaltests') ||
      lowerLine.includes('total =') ||
      lowerLine.includes('count =') ||
      lowerLine.includes('expect(') ||
      lowerLine.includes('backend +') ||
      lowerLine.includes('frontend +')
    ) {
      return 'error';
    }

    // Medium severity (documentation or validation)
    return 'warning';
  }

  /**
   * Validate that dynamic test counting is being used
   */
  async validateDynamicCounting(): Promise<boolean> {
    try {
      const testCountingContent = await readFile('server/test-counting.ts', 'utf-8');
      const workingRunnerContent = await readFile('server/working-test-runner.ts', 'utf-8');

      // Check that test counting uses dynamic calculation
      const hasGetTestCounts = testCountingContent.includes('getTestCounts');
      const hasFileScanning = testCountingContent.includes('scanDirectory') || testCountingContent.includes('readdir');
      const runnerUsesDynamic = workingRunnerContent.includes('testCounter.getTestCounts');

      return hasGetTestCounts && hasFileScanning && runnerUsesDynamic;
    } catch (error) {
      console.error('Error validating dynamic counting:', error);
      return false;
    }
  }

  /**
   * Check for architectural violations
   */
  async validateArchitecture(): Promise<{
    hasDynamicCounting: boolean;
    hardcodeViolations: HardcodeDetectionResult[];
    recommendation: string;
  }> {
    const hasDynamicCounting = await this.validateDynamicCounting();
    const hardcodeViolations = await this.detectHardcodedValues();
    
    let recommendation = 'Test infrastructure architecture is healthy.';
    
    if (!hasDynamicCounting) {
      recommendation = 'CRITICAL: Dynamic test counting system not detected. Ensure testCounter.getTestCounts is being used.';
    } else if (hardcodeViolations.length > 0) {
      const errorCount = hardcodeViolations.reduce((sum, result) => 
        sum + result.violations.filter(v => v.severity === 'error').length, 0);
      
      if (errorCount > 0) {
        recommendation = `WARNING: ${errorCount} critical hardcoded values detected. Review and replace with dynamic calculations.`;
      } else {
        recommendation = `INFO: ${hardcodeViolations.length} potential hardcoded values found. Review for cleanup opportunities.`;
      }
    }

    return {
      hasDynamicCounting,
      hardcodeViolations,
      recommendation
    };
  }
}

export const hardcodeDetector = new HardcodeDetector();