/**
 * Permission Constants
 * 
 * These constants define all permission names used throughout the application.
 * They match exactly with the database permission names for consistency.
 */

export const PERMISSIONS = {
  // User Management
  VIEW_USERS: 'View Users',
  CREATE_USERS: 'Create Users',
  EDIT_USERS: 'Edit Users',
  DELETE_USERS: 'Delete Users',
  DEACTIVATE_USERS: 'Deactivate Users',
  REACTIVATE_USERS: 'Reactivate Users',
  INVITE_USERS: 'Invite Users',
  
  // Role and Permission Management
  VIEW_PERMISSIONS: 'View Permissions',
  MANAGE_PERMISSIONS: 'Manage Permissions',
  MANAGE_USER_ROLES: 'Manage User Roles',
  
  // User Profile Management
  VIEW_USER_PROFILES: 'View User Profiles',
  EDIT_USER_PROFILES: 'Edit User Profiles',
  
  // Session Management
  VIEW_SESSIONS: 'View Sessions',
  MANAGE_SESSIONS: 'Manage Sessions',
  RESET_SESSIONS: 'Reset Sessions',
  VIEW_USER_SESSIONS: 'View User Sessions',
  
  // Blueprint Management
  VIEW_BLUEPRINTS: 'View Blueprints',
  CREATE_BLUEPRINTS: 'Create Blueprints',
  EDIT_BLUEPRINTS: 'Edit Blueprints',
  DELETE_BLUEPRINTS: 'Delete Blueprints',
  MANAGE_BLUEPRINTS: 'Manage Blueprints',
  
  // Credit System
  VIEW_CREDITS: 'View Credits',
  MANAGE_CREDITS: 'Manage Credits',
  ADD_CREDITS: 'ADD_CREDITS',
  VIEW_CREDIT_HISTORY: 'View Credit History',
  PURCHASE_CREDITS: 'Purchase Credits',
  
  // Analytics and Reporting
  VIEW_ANALYTICS: 'View Analytics',
  VIEW_SYSTEM_ANALYTICS: 'View System Analytics',
  VIEW_USER_ANALYTICS: 'View User Analytics',
  GENERATE_REPORTS: 'Generate Reports',
  
  // Message and Communication
  VIEW_MESSAGES: 'View Messages',
  EDIT_MESSAGES: 'Edit Messages',
  DELETE_MESSAGES: 'Delete Messages',
  MODERATE_MESSAGES: 'Moderate Messages',
  
  // Email Management
  MANAGE_EMAIL_SETTINGS: 'Manage Email Settings',
  
  // Invitation System
  SEND_INVITATIONS: 'Send Invitations',
  MANAGE_USER_INVITATIONS: 'Manage User Invitations',
  
  // Notification System
  MANAGE_NOTIFICATIONS: 'Manage Notifications',
  
  // System Settings
  VIEW_SYSTEM_SETTINGS: 'View System Settings',
  MANAGE_SYSTEM_SETTINGS: 'Manage System Settings',
  
  // Security and Audit
  VIEW_SECURITY_LOGS: 'View Security Logs',
  VIEW_AUDIT_LOGS: 'View Audit Logs',
  
  // Email Management
  MANAGE_EMAIL_QUEUE: 'Manage Email Queue',
  
  // Whitelist Management
  MANAGE_WHITELIST: 'Manage Whitelist',
  VIEW_WHITELIST: 'View Whitelist',
  
  // Test System
  MANAGE_TEST_SYSTEM: 'Manage Test System',
  RUN_TESTS: 'Run Tests',
  VIEW_TEST_RESULTS: 'View Test Results',
  
  // Advanced User Management
  MANAGE_USERS: 'Manage Users',
  MANAGE_ROLES: 'Manage Roles',
  
  // Advanced Analytics
  VIEW_SESSION_ANALYTICS: 'View Session Analytics',
  EXPORT_ANALYTICS: 'Export Analytics',
  EXPORT_BLUEPRINTS: 'Export Blueprints',
  
  // Communication System
  SEND_MESSAGES: 'Send Messages',
  
  // Mimic System Permissions
  MIMIC_USERS_READONLY: 'Mimic Users Readonly',
  MIMIC_USERS_FULL: 'Mimic Users Full',
  
  // Privacy Controls for Mimic Access
  MIMIC_COACH_NOT_ACCESSIBLE: 'Mimic Coach Not Accessible',
  MIMIC_ADMIN_NOT_ACCESSIBLE: 'Mimic Admin Not Accessible',
  
  // System Administration
  SYSTEM_ADMIN: 'System Admin'
} as const;

// Type for permission checking
export type Permission = typeof PERMISSIONS[keyof typeof PERMISSIONS];

// Helper function to get all permission values
export function getAllPermissions(): Permission[] {
  return Object.values(PERMISSIONS);
}

// Helper function to check if a string is a valid permission
export function isValidPermission(permission: string): permission is Permission {
  return Object.values(PERMISSIONS).includes(permission as Permission);
}

// Role-based permission mapping for UI access control
export function getRolePermissions(role: string): Permission[] {
  // This would typically fetch from database, but we'll return basic mappings for type safety
  const rolePermissions: Record<string, Permission[]> = {
    user: [
      PERMISSIONS.VIEW_BLUEPRINTS,
      PERMISSIONS.VIEW_CREDITS
    ],
    coach: [
      PERMISSIONS.VIEW_BLUEPRINTS,
      PERMISSIONS.VIEW_CREDITS,
      PERMISSIONS.VIEW_ANALYTICS,
      PERMISSIONS.VIEW_MESSAGES,
      PERMISSIONS.VIEW_USERS,
      PERMISSIONS.MIMIC_USERS_READONLY
    ],
    manager: [
      PERMISSIONS.VIEW_BLUEPRINTS,
      PERMISSIONS.VIEW_CREDITS,
      PERMISSIONS.VIEW_ANALYTICS,
      PERMISSIONS.VIEW_USERS,
      PERMISSIONS.CREATE_USERS,
      PERMISSIONS.EDIT_USERS,
      PERMISSIONS.DELETE_USERS,
      PERMISSIONS.MIMIC_USERS_READONLY,
      PERMISSIONS.MANAGE_USER_INVITATIONS
    ],
    admin: [
      PERMISSIONS.VIEW_USERS,
      PERMISSIONS.CREATE_USERS,
      PERMISSIONS.EDIT_USERS,
      PERMISSIONS.DELETE_USERS,
      PERMISSIONS.MANAGE_CREDITS,
      PERMISSIONS.VIEW_CREDITS,
      PERMISSIONS.VIEW_ANALYTICS,
      PERMISSIONS.MIMIC_USERS_READONLY,
      PERMISSIONS.MIMIC_USERS_FULL,
      PERMISSIONS.MANAGE_SYSTEM_SETTINGS,
      PERMISSIONS.SYSTEM_ADMIN
    ],
    super_admin: getAllPermissions()
  };
  
  return rolePermissions[role] || [];
}

// Helper function to check if a user has a specific permission
export function userHasPermission(user: { role?: string; permissions?: any[] } | null | undefined, permission: Permission): boolean {
  if (!user) return false;
  
  // CRITICAL: Use actual database permissions if available
  if (user.permissions && Array.isArray(user.permissions)) {
    return user.permissions.some(p => p.name === permission);
  }
  
  // Fallback to role-based checks if permissions not loaded
  if (!user.role) return false;
  const userPermissions = getRolePermissions(user.role);
  return userPermissions.includes(permission);
}